launch from gui
